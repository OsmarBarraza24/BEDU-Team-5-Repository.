package com.interviewer;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Discipline implements Serializable {
    static ArrayList<Discipline> data;
    int id;
    String name;
    String description;
    String slug;

    public Discipline(
            String name,
            String description,
            String slug
    ){
        this.id = data.size()+ 1;
        this.name= name;
        this.description= description;
        this.slug = slug;
    }

    public Discipline(
            int id,
            String name,
            String description,
            String slug
    ){
        this.id = id;
        this.name= name;
        this.description= description;
        this.slug = slug;
    }

    public Discipline add() {
        data.add(this);
        Discipline.saveDataToFile();
        return this;
    }

    public void deleteDiscipline(String name){
        Discipline discipline = Discipline.getByName(name);

        if (discipline != null) {
            data.remove(this);
            discipline.saveDataToFile();
            System.out.println("Discipline has been deleted");
        }
        else
            System.out.println("Discipline not found");
    }

    public void delete() throws Exception{
        Discipline discipline = Discipline.getByName(this.name);

        if (discipline != null) {
            data.remove(this);
            discipline.saveDataToFile();
            System.out.println("Discipline has been deleted");
        }
        else
            throw new Exception("Discipline not found");
    }


    public static Discipline getByName(String name) {
        for (Discipline discipline: data) {
            if (discipline.name.equals(name))
                return discipline;
        }

        return null;
    }

    @Override
    public String toString() {
        return "\nID: " + this.id +
                "\nName: " + this.name +
                "\nLast Name: " + this.description +
                "\nIs Active: " + this.slug + "\n";
    }

    public void save(
            String name,
            String description,
            String slug
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if (!name.equals(""))
            this.name = name;

        if (!description.equals(""))
            this.description= description;

        if (!slug.equals(""))
            this.slug = slug;

        data.add(this);
    }


    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./discipline");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(Discipline.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
