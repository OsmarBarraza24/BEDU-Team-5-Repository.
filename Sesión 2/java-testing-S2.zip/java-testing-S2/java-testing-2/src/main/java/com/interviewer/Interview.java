/*package com.interviewer;
import java.util.Date;
import java.io.*;
import java.util.ArrayList;

public class Interview implements Serializable {
    static ArrayList<Interview> data;

    int id;
    String description;
    Interviewer interviewer = new Interviewer("First Name", "First LasName", "mymail@mail.com", true);;
    Candidate candidate;
    Technology technology;
    Discipline discipline;
    InterviewType interviewType;
    String date;
    String time;
    String duration;

    public Interview(
            String description,
            Interviewer interviewer,
            Candidate candidate,
            Technology technology,
            Discipline discipline,
            InterviewType interviewType,
            String date,
            String time,
            String duration

    ) {


        this.id = data.size() + 1;
        this.description = description;
        this.interviewer = new Interviewer(interviewer.name,interviewer.lastName,interviewer.email,interviewer.isActive);
        this.candidate = new Candidate(candidate.id,candidate.name, candidate.lastName, candidate.email, candidate.isActive);
        this.technology = new Technology(technology.id,technology.name,technology.description, technology.slug);
        this.discipline = new Discipline(discipline.id,discipline.name, discipline.description, discipline.slug);
        this.interviewType = new InterviewType(interviewType.id,interviewType.name, interviewType.slug, interviewType.description);
        this.date = date;
        this.time = time;
        this.duration = duration;
    }

    public Interview add() {
        data.add(this);
        Interview.saveDataToFile();
        return this;
    }

    public void delete() throws Exception{
        Interview interview = Interview.getById(this.id);

        if (interview != null) {
            data.remove(this);
            Interview.saveDataToFile();
            System.out.println("Interview has been deleted");
        }
        else
            throw new Exception("Interview not found");
    }

    public void deleteInterview(int id){
        Interview interview = Interview.getById(id);

        if (interview != null) {
            data.remove(this);
            Interview.saveDataToFile();
            System.out.println("Interviewer has been deleted");
        }
        else
            System.out.println("Interviewer not found");
    }

    public void save(
            String description,
            Interviewer interviewer,
            Candidate candidate,
            Technology technology,
            Discipline discipline,
            InterviewType interviewType,
            String date,
            String time,
            String duration
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if(!description.equals(""))
            this.description = description;

        if(interviewer != null)
            this.interviewer = interviewer;

        if (candidate != null)
            this.candidate = candidate;

        if (technology != null)
            this.technology = technology;

        if (discipline != null)
            this.discipline = discipline;

        if (interviewType != null)
            this.interviewType = interviewType;

        if (!date.equals(""))
            this.date = date;

        if (!time.equals(""))
            this.time = time;

        if (!duration.equals(""))
            this.duration = duration;

        data.add(this);
    }

    public static Interview getById(int id) {
        ;
        for (Interview interview: data) {
            if (interview.id == id)
                return interview;
        }

        return null;
    }

    @Override
    public String toString() {
        return "\nID: " + this.id +
                "\nDescription: "+ this.description +
                "\nInterviewer: " + this.interviewer +
                "\nLast Candidate: " + this.candidate +
                "\nTechnology: " + this.technology +
                "\nDiscipline: " + this.discipline +
                "\nInterview Type: " + this.interviewType + "\n" +
                "\nDate: "+ this.date+
                "\nTime: " + this.time+
                "\nDuration" + this.duration;
    }

    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./interviews");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(Interview.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static void loadDataFromFile() {
        try {
            FileInputStream fileInputStreamI = new FileInputStream("./interviews");
            ObjectInputStream inputStreamI = new ObjectInputStream(fileInputStreamI);

            ArrayList<Interview> fileData = (ArrayList<Interview>) inputStreamI.readObject();

            Interview.data.clear();
            Interview.data.addAll(fileData);

            inputStreamI.close();
            fileInputStreamI.close();
        } catch (Exception e) {
            if (!e.getMessage().contains("No such file or directory"))
                e.printStackTrace();
        }
    }


}

 */