package com.interviewer;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Technology {
    static ArrayList<Technology> data;
    int id;
    String name;
    String description;
    String slug;

public Technology(
        String name,
        String description,
        String slug
){
        this.id = data.size()+ 1;
        this.name= name;
        this.description= description;
        this.slug = slug;
}

    public Technology(
            int id,
            String name,
            String description,
            String slug
    ){
        this.id = id;
        this.name= name;
        this.description= description;
        this.slug = slug;
    }

    public Technology add() {
        data.add(this);
        Technology.saveDataToFile();
        return this;
    }

    public void deleteTechnology(String name){
        Technology technology = Technology.getByName(name);

        if (technology != null) {
            data.remove(this);
            technology.saveDataToFile();
            System.out.println("Technology has been deleted");
        }
        else
            System.out.println("Interviewer not found");
    }

    public void delete() throws Exception{
        Technology technology = Technology.getByName(this.name);

        if (technology != null) {
            data.remove(this);
            technology.saveDataToFile();
            System.out.println("Technology has been deleted");
        }
        else
            throw new Exception("Technology not found");
    }


    public static Technology getByName(String name) {
        for (Technology technology: data) {
            if (technology.name.equals(name))
                return technology;
        }

        return null;
    }

    @Override
    public String toString() {
        return "\nID: " + this.id +
                "\nName: " + this.name +
                "\nLast Name: " + this.description +
                "\nIs Active: " + this.slug + "\n";
    }

    public void save(
            String name,
            String description,
            String slug
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if (!name.equals(""))
            this.name = name;

        if (!description.equals(""))
            this.description= description;

        if (!slug.equals(""))
            this.slug = slug;

        data.add(this);
    }


    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./technology");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(Technology.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
