package com.interviewer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class InterviewTypeTest {
    static String nameE = "Entrevista Tecnica";
    static String slugE = "Valor Random";
    static String descriptionE =  "Prueba de test";

    @BeforeEach
    public void setUp() {
        InterviewType.data = new ArrayList<InterviewType>();

        InterviewType.data.add(new InterviewType(
                nameE,
                slugE,
                descriptionE
        ));
    }

    @Test
    public void add() {
        System.out.println("iniciado prueba");

        InterviewType interviewType = new InterviewType("Entrevista", "aaaaa", "Description test");

        interviewType.add();

        int expectedId = InterviewType.data.size();
        assertEquals(expectedId, interviewType.id,"New interviewer ID should be the new List's size" );
    }


    @Test
    public void save() {
        int originalListSize = InterviewType.data.size();
        String expectedLastName = "Test";
        InterviewType interviewType = InterviewType.data.get(0);
        System.out.println(InterviewType.data.size());
        interviewType.save("Test", "asd","asd");

        int newListSize = InterviewType.data.size();
        System.out.println(InterviewType.data.size());
        int lastInterviewerIndex = newListSize - 1;
        InterviewType latestInterviewer = InterviewType.data.get(lastInterviewerIndex);

        assertEquals(
                originalListSize,
                newListSize,
                "List size should be the same"
        );
        assertEquals(
                expectedLastName,
                latestInterviewer.name,
                "Nop"
        );
    }

    @Test
    public void getByName() {
        InterviewType result = InterviewType.getByName(nameE);

        assertNotNull(result, "Interviewer should be found");
        assertEquals(
                nameE,
                result.name,
                "Unexpected Interviewer Name"
        );
    }

    @Test
    public void deleteByName() {
        InterviewType interviewerT = new InterviewType("Test","Test","Test");
        interviewerT.add();
        interviewerT.deleteInterviewType("Test");

        assertNotNull("Interviewer has been deleted");
        assertEquals("Interviewer has been deleted","Interviewer has been deleted");

        interviewerT.deleteInterviewType("mail@email.com");
        assertNotNull("Interviewer not found");
    }
}
