package com.interviewer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class DisciplineTest {

    static String existingDisciplineName= "Java";
    static String existingDisciplineDescription= "Lenguage";
    static String existingDisciplineSlug= "Tech";


    @BeforeEach
    public void setUp() {
        Discipline.data = new ArrayList<Discipline>();

        Discipline.data.add(new Discipline(
                existingDisciplineName,
                existingDisciplineDescription,
                existingDisciplineSlug ));
    }
    @Test
    public void add() {
        System.out.println("Iniciando prueba");

        Discipline discipline = new Discipline("java", "javaee", "tech");

        discipline.add();

        int expectedId = Discipline.data.size();
        assertEquals(expectedId, discipline.id,"New Discipline ID should be the new List's size" );
    }

    @Test
    public void save() {
        int originalListSize = Discipline.data.size();
        String expectedDescription = "New";
        Discipline existingDiscipline = Discipline.data.get(0);
        System.out.println(Discipline.data.size());
        existingDiscipline.save("",expectedDescription,"");

        int newListSize = Discipline.data.size();
        System.out.println(Discipline.data.size());
        int lastDisciplineIndex = newListSize - 1;
        Discipline latestDiscipline = Discipline.data.get(lastDisciplineIndex);

        assertEquals(
                originalListSize,
                newListSize,
                "List size should be the same"
        );
        assertEquals(
                expectedDescription,
                latestDiscipline.description,
                "Description should have been updated"
        );
        assertEquals(
                existingDiscipline.name,
                latestDiscipline.name,
                "Name should have not been updated"
        );
    }

    @Test
    public void getByName() {
        Discipline result = Discipline.getByName(existingDisciplineName);

        assertNotNull(result, "Discipline not found");
        assertEquals(
                existingDisciplineName,
                result.name,
                "Unexpected Discipline Name"
        );
        assertEquals(
                existingDisciplineDescription,
                result.description,
                "Unexpected Discipline Description"
        );
    }

    @Test
    public void deleteByName() {
        Discipline discipline = new Discipline("java", "javaee", "tech");
        discipline.add();
        discipline.deleteDiscipline("java");

        assertNotNull("Discipline has been deleted");
        assertEquals("Discipline has been deleted","Discipline has been deleted");

        discipline.deleteDiscipline("mail@email.com");
        assertNotNull("Interviewer not found");
    }

    @Test
    public void getByNonExistingName() {
        String nonExistingName = "non existing tech";

        Discipline result = Discipline.getByName(nonExistingName);

        assertNull(result, "Interviewer should not be found");
    }


}
