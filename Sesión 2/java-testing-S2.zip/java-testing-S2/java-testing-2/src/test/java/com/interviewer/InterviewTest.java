/*package com.interviewer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class InterviewTest {

    static int id;
    static String existingDescription = "Interview Test";
    Interviewer existingInterviewer;
    Candidate existingCandidate;
    Technology existingTechnology;
    InterviewType existingInterviewType;
    Discipline existingDiscipline;
    static String existingDate = "04/29/22";
    static String existingTime = "12:00:00";
    static String existingDuration = "1:00";

    @BeforeEach
    public void setUp() {
        Interview.data = new ArrayList<Interview>();

        this.existingInterviewer = new Interviewer(1,"TestInterviewer", "UserInterviewer", "mail@email.com",true);
        this.existingCandidate = new Candidate(1,"TestInterviewer", "UserInterviewer", "mail@email.com",true);
        this.existingInterviewType = new InterviewType(1,"Tecnica", "Hello","Entrevista para evaluar conocimientos técnicos");
        this.existingDiscipline = new Discipline(1,"Testing","Testing knowledge","hello");
        this.existingTechnology = new Technology(1,"java", "javaee", "tech");

        this.existingInterviewer.add();
        this.existingInterviewType.add();
        this.existingTechnology.add();
        this.existingCandidate.add();
        this.existingDiscipline.add();

        Interview.data.add(new Interview(
                existingDescription,
                existingInterviewer,
                existingCandidate,
                existingTechnology,
                existingDiscipline,
                existingInterviewType,
                existingDate,
                existingTime,
                existingDuration
        ));

    }

    //@Test
    public void add() {
        System.out.println("iniciado prueba");

        String existingDescription = "Interview Test2";
        Interviewer existingInterviewer = new Interviewer("TestInterviewer2", "UserInterviewer", "mail@email.com",true);
        Candidate existingCandidate = new Candidate("TestInterviewer", "UserInterviewer", "mail@email.com", true);
        Technology existingTechnology = new Technology("java", "javaee", "tech");
        Discipline existingDiscipline = new Discipline("Testing","Testing knowledge","hello");
        InterviewType existingInterviewType = new InterviewType("Tecnica", "Hello","Entrevista para evaluar conocimientos técnicos");
        String existingDate = "04/29/2022";
        String existingTime = "12:00:00";
        String existingDuration = "1:00";

        this.existingInterviewer.add();
        this.existingCandidate.add();
        this.existingTechnology.add();
        this.existingInterviewType.add();
        this.existingDiscipline.add();

        Interview interview = new Interview(existingDescription, existingInterviewer, existingCandidate, existingTechnology, existingDiscipline,existingInterviewType,existingDate, existingTime, existingDescription);

        interview.add();

        int expectedId = Interview.data.size();
        assertEquals(expectedId, interview.id,"New interviewer ID should be the new List's size" );
    }


    //@Test
    public void save() {
        int originalListSize = Interview.data.size();
        String expectedDate = "04/30/2022";
        Interview existingInterview = Interview.data.get(0);
        System.out.println(Interview.data.size());
        existingInterview.save("", null, null, null,null,null,"04/30/2022","","");

        int newListSize = Interview.data.size();
        System.out.println(Interview.data.size());
        int lastInterviewIndex = newListSize - 1;
        Interview latestInterview = Interview.data.get(lastInterviewIndex);

        assertEquals(
                originalListSize,
                newListSize,
                "List size should be the same"
        );
        assertEquals(
                expectedDate,
                latestInterview.date,
                "Date should have been updated"
        );
        assertEquals(
                existingInterview.description,
                latestInterview.description,
                "Description should have not been updated"
        );
    }


    //@Test
    public void getById() {
        Interview result = Interview.getById(existingInterviewer.id);

        assertNotNull(result, "Interview should be found");
        assertEquals(
                existingInterviewer.id,
                result.id,
                "Unexpected Interview id"
        );
        assertEquals(
                existingDescription,
                result.description,
                "Unexpected Interview description"
        );
    }

    //@Test
    public void deleteByEmail() {
        Interviewer interviewer = new Interviewer("Test", "User", "mail@email.com", true);
        interviewer.add();
        interviewer.deleteInterviewer("mail@email.com");

        assertNotNull("Interviewer has been deleted");
        assertEquals("Interviewer has been deleted","Interviewer has been deleted");

        interviewer.deleteInterviewer("mail@email.com");
        assertNotNull("Interviewer not found");
    }

    //@Test
    public void getByNonExistingEmail() {
        String nonExistingEmail = "nonexisting@email.com";

        Interviewer result = Interviewer.getByEmail(nonExistingEmail);

        assertNull(result, "Interviewer should not be found");
    }
}

*/
