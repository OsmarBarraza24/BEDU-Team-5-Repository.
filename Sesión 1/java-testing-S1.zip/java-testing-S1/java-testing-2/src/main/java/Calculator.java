public class Calculator {
    public void method2 (){
        OtherCalculator oc = new OtherCalculator();
        oc.method1();
    }

    public static void main(String[] args) {
        new Calculator();
    }
}
