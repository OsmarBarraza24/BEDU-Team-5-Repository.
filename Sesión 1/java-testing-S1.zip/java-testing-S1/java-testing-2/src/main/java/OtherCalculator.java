public class OtherCalculator {

    public int method1() {
        return 1;
    }
}
