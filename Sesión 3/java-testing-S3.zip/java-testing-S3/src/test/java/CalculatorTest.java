//import com.calculator.Calculator;
//import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.platform.commons.util.StringUtils;

import java.util.concurrent.ThreadLocalRandom;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

public class CalculatorTest {
    private int a, b;
    Calculator calculator = new Calculator();

    @BeforeEach
    void setUp() {
        a = ThreadLocalRandom.current().nextInt();
        b = ThreadLocalRandom.current().nextInt();
    }

    @Test
    void testAdd() {
        int result = calculator.add(a, b);

        assertEquals(a + b, result, "Resultado incorrecto de la suma");
    }

    //@Test
    void testAddThrowsExceptionWhenIsCalledWithInvalidParams() {
        String c = "hello";

        assertThrows(Exception.class, () -> {
            int result = calculator.add(a, 2);

            assertEquals( a + b, result, "Resultado incorrecto de la suma");
        });
    }

    @Test
    void testMultiply() {
        int c = 5;
        int d = 6;
        //assumeTrue(additionResult == a+b);

        int multiplicationResult = calculator.multiply(c, d);

        Assertions.assertEquals(c * d, multiplicationResult, "Resultado incorrecto de la multiplicación");
    }

}
