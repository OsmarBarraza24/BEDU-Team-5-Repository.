
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.condition.OS.MAC;
import static org.junit.jupiter.api.condition.OS.WINDOWS;

public class CalculatorTest2 {
    private int a,b;
    Calculator calculator = new Calculator();
        final List<Integer> numbers = Arrays.asList(1,2,3);
    @BeforeEach
    public void setUp(){
        a = 5;
        b = 5;
    }

    @Test
    @EnabledOnOs(WINDOWS)
    void onlyOnWindowsOs(){
        int result = calculator.add(a, b);
        assertEquals( a + b, result, "Test");
    }

    @Test
    @EnabledOnOs(MAC)
    void onlyOnMac(){
        int result = calculator.add(a, b);
        assertEquals( a + b, result, "Test");
    }

    @Test
    @DisabledIfEnvironmentVariable(named = "ENV", matches = ".*development.*")
    void notOnDeveloperWorkstation(){
        int result = calculator.add(a, b);
        assertEquals( a + b, result, "Test");
    }

    @ParameterizedTest
    @ValueSource(ints = {10,1,2,3,4})
    void sum(int a){
        int result = calculator.add(a,a);
        assertEquals(result, calculator.add(a,a));
    }

    @ParameterizedTest
    @ValueSource(ints = {10,1,2,3,4})
    void mult(int a){
        int result = calculator.multiply(a,a);
        assertEquals(result, calculator.multiply(a,a));
    }

    @DisplayName("Test with different name")
    @Test
    public void testDifferentDisplayName(TestInfo testInfo){

        assertEquals("Test with different name", testInfo.getDisplayName());

    }
}
