import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class quickSortTest {

    //Primer Test. Arreglo vacio
    @Test
    public void quickSorterTest_Empty() {
        int[] arr = new int[]{};
        assertArrayEquals(new int[]{}, quickSort.sort(arr));
    }

    //Segundo Test. Arreglo de un elemento
    @Test
    public void quickSorterTest_OneElement() {
        int[] arr = new int[]{1};
        assertArrayEquals(new int[]{1}, quickSort.sort(arr));
    }

    //Tercer Test. Arreglo de dos elementos ordenados
    @Test
    public void quickSorterTest_TwoElements1() {
        int[] arr = new int[]{1,2};
        assertArrayEquals(new int[]{1,2}, quickSort.sort(arr));
    }

    //Cuarto Test. Arreglo de dos elementos desordenados
    @Test
    public void quickSorterTest_TwoElements2() {
        int[] arr = new int[]{2,1};
        assertArrayEquals(new int[]{1,2}, quickSort.sort(arr));
    }

    //Quinto Test. Arreglo de tres elementos ordenados
    @Test
    public void quickSorterTest_ThreeElements1() {
        int[] arr = new int[]{1,2,3};
        assertArrayEquals(new int[]{1,2,3}, quickSort.sort(arr));
    }

    //Sexto Test. Arreglo de tres elementos desordenados
    @Test
    public void quickSorterTest_ThreeElements2() {
        int[] arr = new int[]{2,1,3};
        assertArrayEquals(new int[]{1,2,3}, quickSort.sort(arr));
    }

    //Séptimo Test. Arreglo de tres elementos desordenados
    @Test
    public void quickSorterTest_ThreeElements3() {
        int[] arr = new int[]{1,3,2};
        assertArrayEquals(new int[]{1,2,3}, quickSort.sort(arr));
    }

    //Octavo Test. Arreglo de tres elementos desordenados
    @Test
    public void quickSorterTest_ThreeElements4() {
        int[] arr = new int[]{3,2,1};
        assertArrayEquals(new int[]{1,2,3}, quickSort.sort(arr));
    }

    //Noveno Test. Arreglo de cuatro elementos ordenados
    @Test
    public void quickSorterTest_FourElements() {
        int[] arr = new int[]{1,2,3,4};
        assertArrayEquals(new int[]{1,2,3,4}, quickSort.sort(arr));
    }

    //Décimo Test. Arreglo de cuatro elementos desordenados
    @Test
    public void quickSorterTest_FourElements2() {
        int[] arr = new int[]{2,1,3,4};
        assertArrayEquals(new int[]{1,2,3,4}, quickSort.sort(arr));
    }

    //Onceavo Test.
    @Test
    public void quickSorterTest_FourElements3() {
        int[] arr = new int[]{2,1,4,3};
        assertArrayEquals(new int[]{1,2,3,4}, quickSort.sort(arr));
    }

    //Doceavo Test.
    @Test
    public void quickSorterTest_FourElements4() {
        int[] arr = new int[]{4,1,3,2};
        assertArrayEquals(new int[]{1,2,3,4}, quickSort.sort(arr));
    }

    //Treceavo Test.
    @Test
    public void quickSorterTest_FiveElements() {
        int[] arr = new int[]{1,2,3,4,5};
        assertArrayEquals(new int[]{1,2,3,4,5}, quickSort.sort(arr));
    }
    //Catorceavo Test.
    @Test
    public void quickSorterTest_FiveElements1() {
        int[] arr = new int[]{5,4,3,2,1};
        assertArrayEquals(new int[]{1,2,3,4,5}, quickSort.sort(arr));
    }

}