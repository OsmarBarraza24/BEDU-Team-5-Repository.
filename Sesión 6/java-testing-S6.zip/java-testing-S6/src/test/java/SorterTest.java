
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SorterTest {
    @Test
    public void SortEmpyList_ShouldReturnEmptyList(){
        int[] arr = new int[]{};
        assertArrayEquals(new int[]{},Sorter.sort(arr));
    }

    @Test
    public void OneElement(){
        int[] arr = new int[]{1};
        assertArrayEquals(new int[]{1},Sorter.sort(arr));
    }

    @Test
    public void TwoElements(){
        int[] arr = new int[]{2,1};
        assertArrayEquals(new int[]{1,2},Sorter.sort(arr));
    }

    @Test
    public void TwoElements2(){
        int[] arr = new int[]{1,2};
        assertArrayEquals(new int[]{1,2},Sorter.sort(arr));
    }

    @Test
    public void TwoElements3(){
        int[] arr = new int[]{2,2};
        assertArrayEquals(new int[]{2,2},Sorter.sort(arr));
    }

    @Test
    public void ThreeElements(){
        int[] arr = new int[]{1,2,3};
        assertArrayEquals(new int[]{1,2,3},Sorter.sort(arr));
    }

    @Test
    public void ThreeElements2(){
        int[] arr = new int[]{2,1,3};
        assertArrayEquals(new int[]{1,2,3},Sorter.sort(arr));
    }

    @Test
    public void ThreeElements3(){
        int[] arr = new int[]{1,3,2};
        assertArrayEquals(new int[]{1,2,3},Sorter.sort(arr));
    }

    @Test
    public void ThreeElements4(){
        int[] arr = new int[]{3,1,2};
        assertArrayEquals(new int[]{1,2,3},Sorter.sort(arr));
    }

    @Test
    public void FourElements(){
        int[] arr = new int[]{1,2,3};
        assertArrayEquals(new int[]{1,2,3},Sorter.sort(arr));
    }



}