import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class bubbleSortTest {

    //Primera prueba. Arreglo vacío.
    @Test
    public void sorterTest() {
        int[] arr = new int[]{};
        assertArrayEquals(new int[]{}, bubbleSort.sorter(arr));
    }

    //Segunda prueba. Arreglo de un elemento.
    @Test
    public void OneElement() {
        int[] arr = new int[]{1};
        assertArrayEquals(new int[]{1}, bubbleSort.sorter(arr));
    }

    //Tercera prueba. Arreglo dos elementos ordenado.
    @Test
    public void twoElements() {
        int[] arr = new int[]{1, 2};
        assertArrayEquals(new int[]{1, 2}, bubbleSort.sorter(arr));
    }

    //Cuarta prueba. Arreglo dos elementos desordenados.
    @Test
    public void twoElements2() {
        int[] arr = new int[]{2, 1};
        assertArrayEquals(new int[]{1, 2}, bubbleSort.sorter(arr));
    }


    //Quinta prueba, Arreglo dos elementos iguales.
    @Test
    public void twoElements3(){
        int[]arr = new int[]{2,2};
        assertArrayEquals(new int[]{2,2}, bubbleSort.sorter(arr));
    }

    //Sexta prueba, Arreglo tres elementos ordenados
    @Test
    public void threeElements(){
        int[]arr = new int[]{1,2,3};
        assertArrayEquals(new int[]{1,2,3}, bubbleSort.sorter(arr));
    }

    //Séptima prueba, Arreglo tres elementos desordenados
    @Test
    public void threeElements2(){
        int[]arr = new int[]{1,3,2};
        assertArrayEquals(new int[]{1,2,3}, bubbleSort.sorter(arr));
    }

    //Octava prueba. Arreglo tres elementos desordenados.
    @Test
    public void threeElements3(){
        int[]arr = new int[]{2,1,3};
        assertArrayEquals(new int[]{1,2,3}, bubbleSort.sorter(arr));
    }

    //Novena prueba. Arreglo de tres elementos desordenados.
    @Test
    public void ThreeElements4(){
        int[] arr = new int[]{3,1,2};
        assertArrayEquals(new int[]{1,2,3},bubbleSort.sorter(arr));
    }

    //Décima prueba. Arreglo de cuatro elementos ordenados.
    @Test
    public void FourElements(){
        int[] arr = new int[]{1,2,3,4};
        assertArrayEquals(new int[]{1,2,3,4},bubbleSort.sorter(arr));
    }

    //Onceava prueba. Arreglo de cuatro elementos ordenados.
    @Test
    public void fourElements1(){
        int[] arr = new int[]{3,4,2,1};
        assertArrayEquals(new int[]{1,2,3,4},bubbleSort.sorter(arr));
    }

}