public class Sorter {

    public static int[] sort(int[] unsorted) {
        int[] sorted = new int[]{};

        if (unsorted.length <= 1)
            return unsorted;

        for(int i = 0; i < unsorted.length; i++)
            for (int j = i+1; j < unsorted.length; j++){
                int temp = 0;
                if(unsorted[i] > unsorted[j]){
                    temp = unsorted[i];
                    unsorted[i] = unsorted[j];
                    unsorted[j] = temp;
                }

            }
        return unsorted;
    }

}
