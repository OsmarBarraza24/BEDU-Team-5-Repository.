package com.example.demo.business;

import com.example.demo.data.SomeDataService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})

class SomeBusinessLogicMockTest {

    @InjectMocks
    SomeBusinessLogic business;

    @Mock
    SomeDataService dataServiceMock;

    //@Test
    public void calculateSumUsingDataService_basic() {
        // Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{1, 2, 3});
        assertEquals(6,business.calculateSumWithADataService());
    }

    //@Test
    public void calculateSumUsingDataService_empty() {
        //Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{});
        assertEquals(0,business.calculateSumWithADataService());
    }


    //@Test
    public void calculateSumUsingDataService_OneElement(){
        //Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{5});
        assertEquals(5,business.calculateSumWithADataService());
    }

    @Test
    public void calculateSubstractionUsingDataService_basic() {
        // Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{-20, 5, 7});
        assertEquals(-32,business.calculateSubstractionWithADataService());
    }

    @Test
    public void calculateSubstractionUsingDataService_empty() {

        //Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{});
        assertEquals(0,business.calculateSubstractionWithADataService());
    }

    @Test
    public void calculateSubstractionUsingDataService_OneElement(){

        //Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{5});
        assertEquals(5,business.calculateSubstractionWithADataService());
    }

    @Test
    public void calculateSubstractionUsingDataService_Multiple() {
        // Arrange
        when(dataServiceMock.retrieveAllData()).thenReturn(new int[]{-20, 5, 7},new int[]{5},new int[]{});
        assertEquals(-32,business.calculateSubstractionWithADataService());
        assertEquals(5,business.calculateSubstractionWithADataService());
        assertEquals(0,business.calculateSubstractionWithADataService());
    }

}
