package com.example.demo.business;

import com.example.demo.data.SomeDataService;

public class SomeBusinessLogic {

    private SomeDataService someDataService;

    public void setSomeDataService(SomeDataService someDataService) {
        this.someDataService = someDataService;
    }

    public int calculateSum(int[] data) {
        int sum = 0;
        for(int value:data) {
            sum += value;
        }
        return sum;
    }

    public int calculateSumWithADataService() {
        int sum = 0;
        int[] data = someDataService.retrieveAllData();
        for(int value:data) {
            sum += value;
        }

        return sum;
    }

    public int calculateSubstractionWithADataService2() {
        int res = 0;
        int [] data = someDataService.retrieveAllData();
        for (int i = 0; i < data.length-1; i++){
            res =  data[0] - data[i+1];
            data[0] = res;

            if(data.length == 1){
                return data[0];
            }
        }
        return res;
    }

    public int calculateSubstractionWithADataService() {
        int res =0;

        int[] data = someDataService.retrieveAllData();

        if(data.length!= 0){
            for(int i = 0; i < data.length; i++){
                if(i == 0)
                    res = data[i];
                else
                    res -= data[i];
            }
        }
        return res;
    }

}
