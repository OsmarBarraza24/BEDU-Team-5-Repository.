package com.interviewer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class TechnologyTest {
    static String existingTechnologyName= "Java";
    static String existingTechnologyDescription= "Lenguage";
    static String existingTechnologySlug= "Tech";


    @BeforeEach
    public void setUp() {
        Technology.data = new ArrayList<Technology>();

        Technology.data.add(new Technology(
                existingTechnologyName,
                existingTechnologyDescription,
                existingTechnologySlug ));
    }
    @Test
    public void add() {
        System.out.println("Iniciando prueba");

        Technology technology = new Technology("java", "javaee", "tech");

        technology.add();

        int expectedId = Technology.data.size();
        assertEquals(expectedId, technology.id,"New Technology ID should be the new List's size" );
    }

    @Test
    public void save() {
        int originalListSize = Technology.data.size();
        String expectedDescription = "New";
        Technology existingTechnology = Technology.data.get(0);
        System.out.println(Technology.data.size());
        existingTechnology.save("",expectedDescription,"");

        int newListSize = Technology.data.size();
        System.out.println(Technology.data.size());
        int lastTechnologyIndex = newListSize - 1;
        Technology latestTechnology = Technology.data.get(lastTechnologyIndex);

        assertEquals(
                originalListSize,
                newListSize,
                "List size should be the same"
        );
        assertEquals(
                expectedDescription,
                latestTechnology.description,
                "Description should have been updated"
        );
        assertEquals(
                existingTechnology.name,
                latestTechnology.name,
                "Name should have not been updated"
        );
    }

    @Test
    public void getByName() {
        Technology result = Technology.getByName(existingTechnologyName);

        assertNotNull(result, "Technology not found");
        assertEquals(
                existingTechnologyName,
                result.name,
                "Unexpected Technology Name"
        );
        assertEquals(
                existingTechnologyDescription,
                result.description,
                "Unexpected Technology Description"
        );
    }

    @Test
    public void deleteByName() {
        Technology technology = new Technology("java", "javaee", "tech");
        technology.add();
        technology.deleteTechnology("java");

        assertNotNull("Technology has been deleted");
        assertEquals("Technology has been deleted","Technology has been deleted");

        technology.deleteTechnology("mail@email.com");
        assertNotNull("Interviewer not found");
    }

    @Test
    public void getByNonExistingName() {
        String nonExistingName = "non existing tech";

        Technology result = Technology.getByName(nonExistingName);

        assertNull(result, "Interviewer should not be found");
    }

}
