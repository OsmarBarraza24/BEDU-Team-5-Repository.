package com.interviewer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class validationTest {
    @BeforeEach
    public void setUp() {

    }

    @Test
    public void validateWrongName(){


        Validation result = new Validation();
        assertEquals(false,result.validateName_LastName("Na"));
    }

    @Test
    public void validateCorrectName(){


        Validation result = new Validation();
        assertEquals(true,result.validateName_LastName("Name"));
    }

    @Test
    public void validateCorrectEmail(){
        final String expectedEmail = "test@test.com";
        Validation result = new Validation();

        assertEquals(true,result.validateEmail(expectedEmail));
    }

    @Test
    public void validateIncorrectEmail(){
        final String expectedEmail = "testtest.com";

        Validation result = new Validation();

        assertEquals(false,result.validateEmail(expectedEmail));
    }

    @Test
    public void validateEmptyEmail(){
        final String expectedEmail = "";

        Validation result = new Validation();
        assertEquals(false,result.validateEmail(expectedEmail));
    }

}
