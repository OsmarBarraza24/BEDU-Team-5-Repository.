package com.interviewer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class MenuTest {
    private final InputStream systemIn = System.in;
    private final PrintStream systemOut = System.out;

    private ByteArrayInputStream testIn;
    private ByteArrayOutputStream testOut;

    @BeforeEach
    public void setUpOutput() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    private void provideInput(String data) {
        testIn = new ByteArrayInputStream(data.getBytes());
        System.setIn(testIn);
    }


    private String getOutput() {
        return testOut.toString();
    }

    @AfterEach
    public void restoreSystemInputOutput() {
        System.setIn(systemIn);
        System.setOut(systemOut);
    }

    @Test
    public void menuAdmin(){
        final String user = "admin";
        final String password = "admin1";
        final String menu = user + "\n" + password + "\n 5 \n ";
        final String expectedOutput = "Bienvenido al menu de administrador";

        provideInput(menu);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(expectedOutput));

    }

    @Test
    public void menuUser(){
        final String menu = "x \n x \n 2 \n";
        final String expectedOutput = "Bienvenido al menu de usuario";

        provideInput(menu);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(expectedOutput));
    }

    @Test
    public void menuAdminAdd(){
        final String user = "admin";
        final String password = "admin1";
        final String correctName = "Pepe";
        final String correctLastName = "Pepe";
        final String correctEmail = "pp@mymail.com";
        final int isActive = 1;
        final String menu = user + "\n" + password + "\n 1 \nPp\n " + correctName + "\nSa\n"+ correctLastName +"\nmp\n" + correctEmail + " \n "+isActive+" \n 2 \n" + correctEmail + " \n 5 \n ";
        final String expectedOutput = "Bienvenido al menu de administrador";
        final String expectedOutput1 = "El nombre es demasiado corto.";
        final String expectedOutput2 = "El formato del email es incorrecto.";
        final String expectedOutput3 = "Entrevistador añadido";

        provideInput(menu);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(expectedOutput));
        assertTrue(output.contains(expectedOutput1));
        assertTrue(output.contains(expectedOutput2));
        assertTrue(output.contains(expectedOutput3));

    }

    @Test
    public void addNewInterviewer() {
        final String interviewerName = "Interviewer Name";
        final String interviewerLastName = "Interviewer Lastname";
        final String interviewerEmail = "Interviewer Email";
        final String addNewInterviewerCommand = "1 \n "+ interviewerName + " \n " + interviewerLastName + " \n " + interviewerEmail + " \n 1 \n 5 \n";
        provideInput(addNewInterviewerCommand);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(interviewerName));
        assertTrue(output.contains(interviewerLastName));
        assertTrue(output.contains(interviewerEmail));
    }


    @Test
    public void getInterviewer () {
        final String interviewerName = "Interviewer Name";
        final String interviewerLastName = "Interviewer Lastname";
        final String interviewerEmail = "interviewer@mail.com";
        final String addNewInterviewerCommand = "1 \n "+ interviewerName + " \n " + interviewerLastName + " \n " + interviewerEmail + " \n 1 \n";
        final String getInterviewerCommand = "2 \n " + interviewerEmail + "\n ";
        final String exitCommand = "5 \n";
        provideInput(addNewInterviewerCommand + getInterviewerCommand + exitCommand);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(interviewerName));
        assertTrue(output.contains(interviewerLastName));
        assertTrue(output.contains(interviewerEmail));
    }

    @Test
    public void modifyInterviewer1(){
        final String interviewerName = "Interviewer Name";
        final String interviewerLastName = "Interviewer Lastname";
        final String interviewerEmail = "interviewer@mail.com";
        final String addNewInterviewerCommand = "1 \n "+ interviewerName + " \n " + interviewerLastName + " \n " + interviewerEmail + " \n 1 \n ";

        final String updateInterviewerName = "update Interviewer Name by email";
        final String updateInterviewerLastName = "update Interviewer Lastname";
        final String updateInterviewerEmail = "updateinterviewer@mail.com";

        final String updateInterviewerCommand = "3 \n " + "1 \n " + interviewerEmail + " \n "+ updateInterviewerName + " \n " + updateInterviewerLastName + " \n " + updateInterviewerEmail + " \n 1 \n 5 \n ";
        provideInput(addNewInterviewerCommand + updateInterviewerCommand);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(updateInterviewerName));
        assertTrue(output.contains(updateInterviewerLastName));
        assertTrue(output.contains(updateInterviewerEmail));
    }
    @Test
    public void modifyInterviewer2(){
        final String interviewerName = "Interviewer Name";
        final String interviewerLastName = "Interviewer Lastname";
        final String interviewerEmail = "interviewer@mail.com";
        final String addNewInterviewerCommand = "1 \n "+ interviewerName + " \n " + interviewerLastName + " \n " + interviewerEmail + " \n 1 \n ";

        final String updateInterviewerName = "update Interviewer Name by id";
        final String updateInterviewerLastName = "update Interviewer Lastname";
        final String updateInterviewerEmail = "updateinterviewer@mail.com";

        final String updateInterviewerCommand = "3 \n " + "2 \n 1 \n " + updateInterviewerName + " \n " + updateInterviewerLastName + " \n " + updateInterviewerEmail + " \n 1 \n 5 \n ";
        provideInput(addNewInterviewerCommand + updateInterviewerCommand);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(updateInterviewerName));
        assertTrue(output.contains(updateInterviewerLastName));
        assertTrue(output.contains(updateInterviewerEmail));
    }

    @Test
    public void eliminateInterviewer(){
        final String interviewerName = "Interviewer Name";
        final String interviewerLastName = "Interviewer Lastname";
        final String interviewerEmail = "interviewer@mail.com";
        final String addNewInterviewerCommand = "1 \n "+ interviewerName + " \n " + interviewerLastName + " \n " + interviewerEmail + " \n 1 \n ";

        final String deleteInterviewerCommand = "4 \n " + interviewerEmail + " \n 5 \n ";
        final String outputExpected = "Interviewer has been deleted";

        provideInput(addNewInterviewerCommand + deleteInterviewerCommand);

        Menu.main(new String[0]);
        final String output = getOutput();

        assertTrue(output.contains(outputExpected));
    }
}
