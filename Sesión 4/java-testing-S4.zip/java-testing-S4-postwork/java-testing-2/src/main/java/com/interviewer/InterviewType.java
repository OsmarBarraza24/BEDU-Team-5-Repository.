package com.interviewer;

import java.io.*;
import java.util.ArrayList;

public class InterviewType implements Serializable {
    static ArrayList<InterviewType> data;

    int id;
    String name;
    String slug;
    String description;

    public InterviewType(
            String name,
            String slug,
            String description
    ) {
        this.id = data.size() + 1;
        this.name = name;
        this.slug = slug;
        this.description = description;
    }
    public InterviewType(
            int id,
            String name,
            String slug,
            String description
    ) {
        this.id = id;
        this.name = name;
        this.slug = slug;
        this.description = description;
    }


    public InterviewType add() {
        data.add(this);
        InterviewType.saveDataToFile();
        return this;
    }

    public void delete() throws Exception{
        InterviewType interviewType = InterviewType.getByName(this.name);
        if (interviewType != null) {
            data.remove(this);
            InterviewType.saveDataToFile();
            System.out.println("Interviewer has been deleted");
        }
        else
            throw new Exception("Interviewer not found");
    }

    public void deleteInterviewType(String name){
        InterviewType interviewType = InterviewType.getByName(name);

        if (interviewType != null) {
            data.remove(this);
            InterviewType.saveDataToFile();
            System.out.println("Interview has been deleted");
        }
        else
            System.out.println("Interview not found");
    }

    public void save(
            String name,
            String slug,
            String description
    ) {
        try {
            this.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        if (!name.equals(""))
            this.name = name;

        if (!slug.equals(""))
            this.slug = slug;

        if (!description.equals(""))
            this.description = description;
        data.add(this);
    }

    public static InterviewType getByName(String name) {
        for (InterviewType interviewerType: data) {
            if (interviewerType.name.equals(name)) {
                return interviewerType;
            }
        }

        return null;
    }

    @Override
    public String toString() {
        return "\nID: " + this.id +
                "\nName: " + this.name +
                "\nSlug: " + this.slug +
                "\nDescription: " + this.description
                + "\n";
    }

    public static void saveDataToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("./interviewType");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

            outputStream.writeObject(InterviewType.data);

            outputStream.close();
            fileOutputStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static void loadDataFromFile() {
        try {
            FileInputStream fileInputStream = new FileInputStream("./interviewType");
            ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);

            ArrayList<InterviewType> fileData = (ArrayList<InterviewType>) inputStream.readObject();

            InterviewType.data.clear();
            InterviewType.data.addAll(fileData);

            inputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            if (!e.getMessage().contains("No such file or directory"))
                e.printStackTrace();
        }
    }

}
