package com.interviewer;

public class Validation {

    public boolean validateName_LastName(String validate){
        if(validate.length() > 3){
            if(validate.matches("[a-zA-Z ]*"))
                return true;
            else {
                System.out.println("Nombre incorrecto. Ingrese un nombre sin números.");
                return false;
            }
        }
        System.out.println("El nombre es demasiado corto.");
        return false;
    }

    public boolean validateEmail(String email){
        String pattern = "^[A-Za-z0-9+_.-]+@(.+)$";
        if(!email.isEmpty()){
            if(email.matches(pattern))
                return true;
            else {
                System.out.println("El formato del email es incorrecto.");
                return false;
            }
        }

        return false;

    }

}
