package com.interviewer;

import java.util.ArrayList;
import java.util.Scanner;


public class Menu {
    Scanner sc;

    public Menu() {
        sc = new Scanner(System.in);
        Interviewer.data = new ArrayList<Interviewer>();

        loginMenu();
    }
    public void loginMenu(){
        System.out.println("Ingrese su usuario:");
        String user = sc.nextLine();
        System.out.println("Ingrese su contraseña:");
        String password = sc.nextLine();

        if(user.equals("admin") && password.equals("admin1")) {
            showMainMenu();
        }
        else
            showUserMenu();



    }

    public void showUserMenu() {
        System.out.println("Bienvenido al menu de usuario");

        int option = 0;

        while (option != 2) {
            System.out.println("Seleccione la operacion a realizar:");
            System.out.println("1. Consultar un entrevistador");
            System.out.println("2. Salir");

            option = sc.nextInt();
            sc.nextLine();

                switch (option) {
                    case 1:
                        searchInterviewer();
                        break;
                }
        }
        ;
        System.out.println("Programa terminado");
    }

    public void showMainMenu() {
        System.out.println("Bienvenido al menu de administrador");

        int option = 0;

        while (option != 5) {
            System.out.println("Seleccione la operacion a realizar:");
            System.out.println("1. Dar de alta un entrevistador");
            System.out.println("2. Consultar un entrevistador");
            System.out.println("3. Modificar un entrevistador");
            System.out.println("4. Eliminar un entrevistador");
            System.out.println("5. Salir");

            option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1:
                    addInterviewer();
                    break;
                case 2:
                    searchInterviewer();
                    break;
                case 3:
                    selectInterviewer();
                    break;
                case 4:
                    //System.out.println("Ingrese email del entrevistador a elimiar");
                    deleteInterviewer();
                    break;
            }
        }
        ;

        System.out.println("Programa terminado");
    }

    public void addInterviewer() {
        Validation v = new Validation();
        String name= "";
        String lastName = "";
        String email = "";


        do {
            System.out.println("Ingrese el nombre del entrevistador: ");
            name = sc.nextLine();
        }while(!v.validateName_LastName(name));

        do {
            System.out.println("Ingrese el apellido del entrevistador: ");
            lastName = sc.nextLine();
        }while(!v.validateName_LastName(lastName));

        do {
            System.out.println("Ingrese el email del entrevistador: ");
            email = sc.nextLine();
        }while(!v.validateEmail(email));

        System.out.println("El entrevistador se encuentra activo? (1=Si/2=No)");
        Boolean isActive = sc.nextInt() == 1;


        sc.nextLine();

        Interviewer interviewer = new Interviewer(name, lastName, email, isActive);
        interviewer.add();
        System.out.println("Entrevistador añadido");
        System.out.println(interviewer.toString());
    }

    public void searchInterviewer() {
        System.out.println("Ingrese el email del entrevistador a consultar:");
        String email = sc.nextLine();

        Interviewer interviewer = Interviewer.getByEmail(email);

        if (interviewer != null) {
            System.out.println("Entrevistador encontrado:");
            System.out.println(interviewer.toString());
        } else {
            System.out.println("Entrevistador no encontrado");
        }
    }
    public void selectInterviewer(){
        Interviewer interviewer;

        System.out.println("Seleccione el campo por el que desea buscar el entrevistador a modificar: \n1. Email\n2. ID");
        int option = sc.nextInt();
        sc.nextLine();

        if(option == 1) {
            System.out.println("Ingrese el email del entrevistador a modificar:");
            String email = sc.nextLine();
            interviewer = Interviewer.getByEmail(email);
        }else{
            System.out.println("Ingrese el id del entrevistador a modificar:");
            int id = sc.nextInt();
            sc.nextLine();
            interviewer = Interviewer.getById(id);
        }

        modifyInterviewer(interviewer);
    }
    public void modifyInterviewer(Interviewer interviewer) {

        if (interviewer != null) {
            System.out.println("Entrevistador encontrado:");
            System.out.println(interviewer.toString());

            System.out.println("Ingrese el nuevo nombre del entrevistador: (Enter para mantener actual)");
            String name = sc.nextLine();
            System.out.println("Ingrese el nuevo apellido del entrevistador: (Enter para mantener actual)");
            String lastName = sc.nextLine();
            System.out.println("Ingrese el nuevo email del entrevistador: (Enter para mantener actual)");
            String newEmail = sc.nextLine();
            System.out.println("El entrevistador se encuentra activo? (1=Si/2=No)");
            Boolean isActive = sc.nextInt() == 1;
            sc.nextLine();

            interviewer.save(name, lastName, newEmail, isActive);
            System.out.println(interviewer.toString());

        } else {
            System.out.println("Entrevistador no encontrado");
        }
    }

    public void deleteInterviewer(){
        System.out.println("Ingrese el email del entrevistador a eliminar:");
        String email = sc.nextLine();

        Interviewer interviewer = Interviewer.getByEmail(email);
        try {
            interviewer.delete();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Menu();
    }
}